//
//  SampleFramwork.h
//  SampleFramwork
//
//  Created by AL02029130 on 31/10/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleFramwork.
FOUNDATION_EXPORT double SampleFramworkVersionNumber;

//! Project version string for SampleFramwork.
FOUNDATION_EXPORT const unsigned char SampleFramworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleFramwork/PublicHeader.h>


